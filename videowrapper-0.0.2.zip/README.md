#Videowrapper
This extension creates responsive embed code for video's on Youtube and Vimeo. It presumes your website's CSS has a .videowrapper class to handle all that. This script merely removes fixed dimensions.

A ported version for Firefox can be found at github.com/wvdijk/videowrapper-xpi

Known issues:
- regex for Vimeo doesn't work for collections, staff picks etc
- no visible user feedback is given when the extension's browser button is clicked
